
import streamlit as st
from multiapp import MultiApp
from apps import data_viz, classification, clustering, association, regression

app = MultiApp()

# Add all your application here
app.add_app("Data Visualisation", data_viz.app)
app.add_app("Classification", classification.app)
app.add_app("Clustering", clustering.app)
app.add_app("Association Rule Mining", association.app)
app.add_app("Regression Analysis", regression.app)

# The main app
app.run()
