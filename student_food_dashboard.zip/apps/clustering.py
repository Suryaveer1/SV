# Clustering tab code will go here

def app():
    st.title('Clustering Module')
    st.write('Coming soon...')