# Regression tab code will go here

def app():
    st.title('Regression Module')
    st.write('Coming soon...')