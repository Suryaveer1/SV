# Data_viz tab code will go here

def app():
    st.title('Data_viz Module')
    st.write('Coming soon...')