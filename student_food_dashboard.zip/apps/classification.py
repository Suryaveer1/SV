# Classification tab code will go here

def app():
    st.title('Classification Module')
    st.write('Coming soon...')