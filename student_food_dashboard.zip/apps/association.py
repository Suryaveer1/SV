# Association tab code will go here

def app():
    st.title('Association Module')
    st.write('Coming soon...')