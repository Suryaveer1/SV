
# Student Food Delivery Insights Dashboard

This Streamlit dashboard is built to visualize, analyze, and model synthetic data for a student food delivery startup. Hosted on Streamlit Cloud, it includes multiple tabs:
- Data Visualisation
- Classification (KNN, DT, RF, GBRT)
- Clustering (K-Means)
- Association Rule Mining (Apriori)
- Regression (Linear, Ridge, Lasso, Decision Tree)

## File Structure

- `app.py`: Main file to run the Streamlit app
- `multiapp.py`: Manages multiple tabs
- `apps/`: Contains the code for each tab
- `requirements.txt`: Package dependencies
- `README.md`: Project overview
